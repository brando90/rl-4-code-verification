import Mathlib
namespace Tiny
def solution (p q : Bool) : Bool := p || q
theorem spec_commutative (p q : Bool) : solution p q = solution q p := by
  cases p <;> cases q <;> decide
theorem test_false_false : solution false false = false := by decide
theorem test_false_true : solution false true = true := by decide
end Tiny
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution true false)))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution false true)))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution true true)))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution true true)))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution false true)))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution true true)))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution false true)))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution true true)))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution true false)))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution false true)))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution false true)))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution false true)))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution false true)))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution false true)))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution true false)))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution false true)))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution true false)))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution true false)))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution true false)))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution false false)))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution true false)))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution false true)))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution true false)))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution true true)))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution false true)))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution false false)))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution false false)))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution false false)))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution true true)))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution true false)))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution false false)))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution false false)))
