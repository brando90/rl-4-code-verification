import Mathlib
namespace Tiny
def solution (x : Int) (xs : List Int) : Int := xs.getD 1 x
theorem spec_pair (x a b : Int) (xs : List Int) : solution x (a :: b :: xs) = b := by rfl
theorem test_second : solution 9 [2, 3] = 3 := by decide
theorem test_default : solution 9 [2] = 9 := by decide
example : solution 9 [2, 3] = 3 := test_second
end Tiny
