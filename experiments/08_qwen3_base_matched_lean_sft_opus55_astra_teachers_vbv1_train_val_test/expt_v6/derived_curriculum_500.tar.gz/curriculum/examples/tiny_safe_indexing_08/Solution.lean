import Mathlib
namespace Tiny
def solution (x : Int) (xs : List Int) : Int := ([x] ++ xs).headD x
theorem spec_value (x : Int) (xs : List Int) : solution x xs = x := by rfl
theorem test_nonempty : solution 9 [2, 3] = 9 := by decide
theorem test_empty : solution 9 [] = 9 := by decide
example : solution 9 [2, 3] = 9 := test_nonempty
end Tiny
