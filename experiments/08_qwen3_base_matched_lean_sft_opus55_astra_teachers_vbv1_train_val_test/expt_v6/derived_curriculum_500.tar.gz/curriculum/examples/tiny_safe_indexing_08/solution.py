def solution(x: int, xs: list[int]):
    return ([x] + xs)[0]
