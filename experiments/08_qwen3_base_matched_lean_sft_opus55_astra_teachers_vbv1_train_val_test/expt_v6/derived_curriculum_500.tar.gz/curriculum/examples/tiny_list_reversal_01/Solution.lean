import Mathlib
namespace Tiny
def solution (xs : List Int) : List Int := xs.reverse
theorem spec_length (xs : List Int) : (solution xs).length = xs.length := by simp [solution]
theorem test_empty : solution [] = [] := by decide
theorem test_order : solution [1, -2, 3] = [3, -2, 1] := by decide
example : solution [] = [] := test_empty
end Tiny
