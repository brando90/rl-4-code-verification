import Mathlib
namespace Tiny
def solution (xs ys : List Int) : Bool := decide (xs.toFinset ∪ ys.toFinset = ys.toFinset ∪ xs.toFinset)
theorem spec_commutative (xs ys : List Int) : solution xs ys = true := by
  simp [solution, Finset.union_comm]
theorem test_empty : solution [] [1] = true := by decide
theorem test_overlap : solution [1, 2] [2, 3] = true := by decide
example : solution [] [1] = true := test_empty
end Tiny
#print axioms Tiny.spec_commutative
#print axioms Tiny.test_empty
#print axioms Tiny.test_overlap
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution [] [])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution [(-2)] [(-1), (4), (3)])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution [(-1)] [(3), (2)])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution [] [])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution [] [(1), (-3)])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution [] [(2), (1)])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution [(-1)] [(-2), (-1), (-4), (1), (-1), (-3)])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution [] [(-1), (-3), (-1), (4), (2)])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution [] [(0), (1), (4), (3), (-1)])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution [(0), (1), (3), (0), (2), (3)] [(4), (0), (-1), (4), (-4)])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution [(1), (0), (-3), (2), (1), (0)] [(2), (4)])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution [(-1)] [(4)])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution [(-2), (3), (-1), (-4)] [(-1), (3)])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution [(-3), (-1), (2), (-1), (-3)] [(1), (4), (0), (4)])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution [] [(0)])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution [(2), (1), (-2), (3), (3)] [(0)])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution [(-3), (-2), (-3), (1)] [(3)])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution [(4), (-1), (3), (-2), (-1)] [(2), (3)])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution [] [(4), (1)])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution [] [(4), (-3), (-2), (3), (-1)])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution [(2)] [(0), (1), (-1), (-2), (4), (4)])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution [] [(-2)])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution [(0), (2), (-3), (4)] [(3)])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution [(4), (2), (3), (4)] [(-1)])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution [(-4), (-1), (3), (-3)] [(-3), (4), (-3), (-4)])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution [(3), (1), (0), (4)] [(3), (0), (-3), (0)])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution [(-4), (0)] [(1), (-2), (2), (0), (-3)])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution [(4), (4), (-2), (2), (0), (-2)] [(-2), (2), (-4), (-1)])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution [(-1), (3), (-1), (1), (4), (-2)] [])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution [(4)] [])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution [(4), (-3), (-4), (3)] [(0), (0), (0), (2), (4)])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution [(4), (0), (2), (0), (4)] [(1)])))
