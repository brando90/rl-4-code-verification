import Mathlib
namespace Tiny
def solution (x y : Int) (xs : List Int) : List Int := xs.filter fun a => decide (x <= a ∧ a <= y)
theorem spec_members (a x y : Int) (xs : List Int) : a ∈ solution x y xs ↔ a ∈ xs ∧ x <= a ∧ a <= y := by simp [solution, and_assoc]
theorem test_range : solution (-1) 2 [-2, -1, 0, 2, 3] = [-1, 0, 2] := by decide
theorem test_reversed : solution 3 1 [0, 2, 4] = [] := by decide
example : solution (-1) 2 [-2, -1, 0, 2, 3] = [-1, 0, 2] := test_range
end Tiny
#print axioms Tiny.spec_members
#print axioms Tiny.test_range
#print axioms Tiny.test_reversed
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-5) (3) [])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-4) (6) [(-2)])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (1) (-1) [(3), (1)])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-3) (6) [(2)])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (1) (0) [(2), (-2)])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-3) (-6) [(1)])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-3) (4) [(-2)])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (1) (1) [(2), (-3), (4)])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-1) (-1) [(4), (-4)])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (5) (-1) [(0)])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (6) (4) [(2), (3), (2), (2), (-4)])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (3) (-5) [(-1), (-2), (4), (-4)])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (3) (6) [])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-2) (2) [(-3)])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (6) (-3) [(2)])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-2) (-4) [])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-6) (3) [])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-2) (-2) [(0), (3), (-2), (3), (1), (-3)])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (0) (-4) [(2), (-3), (-2)])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (0) (5) [])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (1) (-5) [(1), (-4), (4)])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-6) (2) [(-1), (-4), (4)])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (3) (-1) [(0), (-2), (-2), (4), (-1)])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (6) (4) [(2), (-1), (-1), (2), (2)])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (0) (5) [(-3), (-1), (2), (1), (-1), (-1)])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (3) (0) [(4), (2), (0)])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (6) (0) [(-3), (-2), (4)])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-3) (-6) [(0), (-2), (1), (0), (-2)])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-6) (3) [(-2), (1), (-2), (-3), (0), (-2)])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (4) (-3) [(-1), (3), (-3), (0), (3)])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (6) (-4) [])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-6) (1) [(-1), (3), (2), (4)])))
