import Mathlib
namespace Tiny
def solution (x : Int) (pair : Int × Int) : Int × Int := (pair.1 * x, pair.2 * x)
theorem spec_zero (pair : Int × Int) : solution 0 pair = (0, 0) := by simp [solution]
theorem test_positive : solution 2 (3, 4) = (6, 8) := by norm_num [solution]
theorem test_negative : solution (-2) (-3, 4) = (6, -8) := by norm_num [solution]
example : solution 2 (3, 4) = (6, 8) := test_positive
end Tiny
#print axioms Tiny.spec_zero
#print axioms Tiny.test_positive
#print axioms Tiny.test_negative
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-5) ((0), (3)))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (4) ((-3), (-2)))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-5) ((3), (-1)))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-2) ((2), (-2)))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (0) ((2), (3)))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-6) ((-3), (-4)))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (0) ((-1), (2)))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (5) ((-4), (1)))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-6) ((-4), (2)))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-1) ((2), (3)))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (1) ((3), (-4)))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-1) ((2), (-2)))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-5) ((0), (-1)))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (3) ((-1), (2)))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (6) ((-2), (0)))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-5) ((-4), (-1)))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (1) ((-2), (3)))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (1) ((4), (-1)))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-4) ((-3), (4)))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (0) ((2), (2)))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-3) ((4), (3)))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-6) ((1), (-1)))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-2) ((3), (0)))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (3) ((-4), (-4)))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (1) ((-1), (0)))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (3) ((-2), (-1)))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (5) ((2), (-4)))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (6) ((4), (-4)))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-3) ((0), (-3)))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (6) ((-2), (2)))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-5) ((3), (4)))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (6) ((2), (0)))))
