import Mathlib
namespace Tiny
def solution (x y z : Nat) : Nat := x + (y - z)
theorem spec_no_extra (x y z : Nat) (h : y ≤ z) : solution x y z = x := by
  simp [solution, Nat.sub_eq_zero_of_le h]
theorem test_positive : solution 2 7 3 = 6 := by norm_num [solution]
theorem test_clamped : solution 2 3 7 = 2 := by norm_num [solution]
example : solution 2 7 3 = 6 := test_positive
end Tiny
#print axioms Tiny.spec_no_extra
#print axioms Tiny.test_positive
#print axioms Tiny.test_clamped
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (5) (5) (3))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (6) (2) (4))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (0) (6) (3))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (3) (0) (5))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (4) (0) (2))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (0) (3) (2))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (5) (5) (0))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (5) (3) (2))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (6) (1) (0))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (1) (5) (1))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (1) (0) (0))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (4) (4) (6))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (2) (3) (4))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (0) (3) (0))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (5) (5) (3))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (5) (3) (0))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (3) (1) (6))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (4) (2) (1))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (4) (6) (6))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (4) (0) (1))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (6) (2) (1))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (4) (3) (5))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (0) (2) (5))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (2) (2) (1))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (0) (1) (0))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (2) (6) (4))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (4) (4) (1))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (6) (6) (3))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (4) (6) (3))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (6) (1) (0))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (5) (3) (1))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (2) (5) (2))))
