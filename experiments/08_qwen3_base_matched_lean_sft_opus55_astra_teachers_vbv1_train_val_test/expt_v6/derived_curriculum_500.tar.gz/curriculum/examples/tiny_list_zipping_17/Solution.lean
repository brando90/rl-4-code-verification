import Mathlib
namespace Tiny
def solution (xs ys : List Int) : List (Int × Int) := xs.reverse.zip ys
theorem spec_empty_right (xs : List Int) : solution xs [] = [] := by simp [solution]
theorem test_reverses : solution [1, 2, 3] [4, 5] = [(3, 4), (2, 5)] := by decide
theorem test_empty : solution [] [4] = [] := by decide
example : solution [1, 2, 3] [4, 5] = [(3, 4), (2, 5)] := test_reverses
end Tiny
