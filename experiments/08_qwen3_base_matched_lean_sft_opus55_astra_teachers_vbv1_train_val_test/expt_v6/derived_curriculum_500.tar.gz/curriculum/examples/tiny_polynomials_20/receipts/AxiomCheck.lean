import Mathlib

namespace Tiny

def solution (x y : Int) : Int := (x - y) * (x - y)

theorem spec_square (x y : Int) : solution x y = (x - y) ^ 2 := by
  simp [solution]
  ring

theorem test_positive : solution 5 2 = 9 := by decide
theorem test_negative : solution (-4) 1 = 25 := by decide

example : solution 5 2 = 9 := test_positive
end Tiny
#print axioms Tiny.spec_square
#print axioms Tiny.test_positive
#print axioms Tiny.test_negative
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-6) (-6))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (1) (-1))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (4) (-5))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (5) (5))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-2) (-2))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-3) (2))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-2) (2))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (2) (-5))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-1) (4))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-4) (3))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-3) (-6))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (6) (3))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (0) (-5))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (1) (-2))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-6) (5))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-2) (1))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-5) (3))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (6) (4))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (2) (5))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (3) (-6))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-3) (3))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-4) (-5))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (0) (-4))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (1) (1))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-6) (1))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (1) (5))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (2) (1))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-6) (2))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-2) (-4))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-2) (4))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (1) (4))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-5) (-3))))
