import Mathlib
namespace Tiny
def solution (xs ys : List Int) : List Int := xs ++ ys ++ ys
theorem spec_length (xs ys : List Int) : (solution xs ys).length = xs.length + ys.length + ys.length := by simp [solution, Nat.add_assoc]
theorem test_empty : solution [] [1] = [1, 1] := by decide
theorem test_repeat : solution [2] [-1, 3] = [2, -1, 3, -1, 3] := by decide
example : solution [] [1] = [1, 1] := test_empty
end Tiny
