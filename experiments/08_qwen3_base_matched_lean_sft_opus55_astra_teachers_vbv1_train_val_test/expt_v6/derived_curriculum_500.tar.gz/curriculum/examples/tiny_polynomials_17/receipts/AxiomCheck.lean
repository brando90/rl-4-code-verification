import Mathlib

namespace Tiny

def solution (x y : Int) : Int := x ^ 3 + 3 * x ^ 2 * y + 3 * x * y ^ 2 + y ^ 3

theorem spec_binomial (x y : Int) : solution x y = (x + y) ^ 3 := by
  simp [solution]
  ring

theorem test_positive : solution 1 2 = 27 := by decide
theorem test_negative : solution (-3) 1 = -8 := by decide

example : solution 1 2 = 27 := test_positive
end Tiny
#print axioms Tiny.spec_binomial
#print axioms Tiny.test_positive
#print axioms Tiny.test_negative
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-2) (-3))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (1) (-1))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (6) (0))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-2) (1))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-5) (6))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-1) (-2))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-4) (3))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (5) (1))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (3) (2))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-2) (-4))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-1) (-4))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (0) (-1))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-1) (2))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-2) (5))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (1) (0))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (1) (0))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (4) (-6))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (4) (2))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (2) (-3))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (4) (1))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (2) (3))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-5) (6))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-1) (5))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-5) (6))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-6) (5))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-1) (3))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-2) (-6))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-5) (2))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-2) (0))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (1) (5))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-2) (3))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-1) (5))))
