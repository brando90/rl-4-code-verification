def solution(x: int, y: int):
    return x ** 3 + 3 * x ** 2 * y + 3 * x * y ** 2 + y ** 3
