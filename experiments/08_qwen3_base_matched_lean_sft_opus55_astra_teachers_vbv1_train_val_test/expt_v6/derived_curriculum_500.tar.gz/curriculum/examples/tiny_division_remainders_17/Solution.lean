import Mathlib
namespace Tiny
def solution (x : Int) : Int := (2 * x) / 2
theorem spec_identity (x : Int) : solution x = x := by simp [solution]
theorem test_negative : solution (-7) = -7 := by norm_num [solution]
theorem test_positive : solution 8 = 8 := by norm_num [solution]
example : solution (-7) = -7 := test_negative
end Tiny
