import Mathlib
namespace Tiny
def solution (x y : Int) (xs : List Int) : List Int := xs.filter fun a => decide (a < x ∨ a > y)
theorem spec_members (a x y : Int) (xs : List Int) : a ∈ solution x y xs ↔ a ∈ xs ∧ (a < x ∨ a > y) := by simp [solution]
theorem test_outside : solution (-1) 2 [-2, -1, 0, 2, 3] = [-2, 3] := by decide
theorem test_reversed : solution 3 1 [0, 2, 4] = [0, 2, 4] := by decide
example : solution (-1) 2 [-2, -1, 0, 2, 3] = [-2, 3] := test_outside
end Tiny
#print axioms Tiny.spec_members
#print axioms Tiny.test_outside
#print axioms Tiny.test_reversed
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (5) (-6) [])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (4) (2) [(3), (2), (0), (2), (4), (4)])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (3) (0) [(-4), (4), (4), (3), (-1), (0)])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-6) (2) [(-1), (-3), (-1)])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (5) (2) [(3)])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (3) (2) [(2), (0), (2), (4), (3), (3)])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (4) (0) [(4), (-2)])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (0) (5) [])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (5) (-1) [(1), (-1)])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (1) (-4) [])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (5) (2) [(2), (-4), (0)])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-2) (0) [(2), (4), (4), (-3)])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (0) (1) [(0), (-4), (-2), (1), (-2)])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-6) (-3) [(-1)])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-2) (0) [(3), (-1)])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-6) (6) [(-3), (3), (0)])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (0) (6) [(-3)])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (6) (-2) [(3), (3), (-3), (1), (0), (-4)])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (1) (-4) [(-2), (1)])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (3) (-3) [(0), (-2)])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-1) (-4) [(3), (0), (2), (-2)])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (5) (-2) [])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-6) (-2) [(4), (-2), (-3), (2), (4), (2)])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (1) (3) [(1)])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-2) (4) [])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (6) (1) [(1), (3), (0), (-4), (-2), (-4)])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (0) (0) [])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-5) (5) [(4), (-4), (4), (4), (-2), (4)])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (2) (2) [])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-3) (-3) [(4), (-1), (2), (-1), (-4)])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-6) (0) [(3), (0), (1), (2), (1), (1)])))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (3) (0) [(-2), (2)])))
