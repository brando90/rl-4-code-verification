import Mathlib
namespace Tiny
def solution (x : Int) : Bool := (2 * x) % 2 == 0
theorem spec_always_even (x : Int) : solution x = true := by
  simp [solution, Int.mul_emod]
theorem test_positive : solution 7 = true := by decide
theorem test_negative : solution (-4) = true := by decide
example : solution 7 = true := test_positive
end Tiny
#print axioms Tiny.spec_always_even
#print axioms Tiny.test_positive
#print axioms Tiny.test_negative
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-6))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-5))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (2))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (3))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (5))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (6))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-3))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-5))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (1))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-5))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (5))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-6))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (1))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-4))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-4))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-6))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-5))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (4))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (5))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (4))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (6))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-3))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (4))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-4))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-1))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (0))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (5))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (2))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-2))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (-2))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (4))))
#eval IO.println (Lean.Json.compress (Lean.toJson (Tiny.solution (4))))
