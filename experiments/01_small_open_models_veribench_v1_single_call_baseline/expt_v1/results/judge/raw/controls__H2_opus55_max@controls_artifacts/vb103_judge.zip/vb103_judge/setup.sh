#!/bin/bash
# TLDR: Make sure a Python 3 interpreter with HTTPS exists; experiment 103's judge agent needs nothing else (standard library only).
set -euo pipefail
export DEBIAN_FRONTEND=noninteractive

if ! command -v python3 >/dev/null 2>&1; then
  if command -v apt-get >/dev/null 2>&1; then
    apt-get -o Acquire::Check-Valid-Until=false update -qq && apt-get install -y -q python3 ca-certificates
  elif command -v yum >/dev/null 2>&1; then
    yum install -y python3 ca-certificates
  elif command -v apk >/dev/null 2>&1; then
    apk add --no-cache python3 ca-certificates
  else
    echo "vb103_judge setup found no package manager able to install python3" >&2
    exit 1
  fi
fi

# A bundle unpacks at /bundle/<contract name>/, so this script locates its own directory rather than
# hardcoding a path (the VBV1 installer's hardcoded assert is what killed the first VBV2 admission).
VB103_BUNDLE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export VB103_BUNDLE_DIR

python3 - <<'PY'
import os, ssl, sys
from pathlib import Path
bundle = Path(os.environ['VB103_BUNDLE_DIR'])
assert (bundle / 'judge_call.py').is_file(), f'judge agent script missing from the bundle at {bundle}'
ssl.create_default_context()
print('vb103_judge setup ok on', sys.version.split()[0], 'in', bundle)
PY
