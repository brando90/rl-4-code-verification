#!/usr/bin/env python3
"""TLDR: Experiment 103's judge transport agent — recover the frozen judge prompt bytes from the task file, verify their SHA-256, send exactly one Vals model-gateway request with experiment 100's request envelope, and write the raw completion to the declared path; no tools, no parsing, no retry after a served call."""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import socket
import ssl
import sys
import time
import urllib.error
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

LOGS = Path(os.environ.get("VB103_LOGS_DIR", "/logs/vb103"))
HEADER_RE = re.compile(r"^<!-- vb103-judge-cell: (?P<json>\{.*\}) -->$", re.M)
SYS_BEGIN, SYS_END = "=== VB103_JUDGE_SYSTEM_BEGIN ===", "=== VB103_JUDGE_SYSTEM_END ==="
USER_BEGIN, USER_END = "=== VB103_JUDGE_USER_BEGIN ===", "=== VB103_JUDGE_USER_END ==="
CLEAN_FINISH = {"stop", "stop_sequence", "end_turn"}
# Experiment 100's judge_run.py sends exactly these provider settings; the judge is a frozen
# configuration, so the envelope is copied rather than re-derived. Anthropic additionally gets an
# explicit empty fallback list (an empty provider_config silently disables adaptive thinking).
ANTHROPIC_ALLOWED = {"supports_compute_effort", "supports_auto_thinking", "task_budget_tokens",
                     "returns_thinking_truncated_turns"}
# Non-Anthropic selectors use experiment 95's recovery allow-list verbatim (the set whose members
# the /query schema accepted after the HTTP 400s of 09-15-2026), which is what judge_run.py imports.
OPENAI_ALLOWED = {"deep_research", "tool_call_mode", "verbosity", "prompt_cache_retention",
                  "prompt_cache_key", "reasoning_context", "parallel_tool_calls", "stream_completions"}


def stamp() -> str:
    return datetime.now(timezone.utc).isoformat()


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


class NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *a, **k):
        raise ValueError("gateway redirects prohibited")


def _opener():
    return urllib.request.build_opener(NoRedirect(), urllib.request.HTTPSHandler(context=ssl.create_default_context()))


def gateway_request(route: str, payload: dict, timeout: float) -> dict:
    url = os.environ["MODEL_GATEWAY_URL"].rstrip("/") + route
    request = urllib.request.Request(
        url, headers={"Authorization": "Bearer " + os.environ["MODEL_GATEWAY_API_KEY"],
                      "Content-Type": "application/json"},
        data=json.dumps(payload).encode())
    with _opener().open(request, timeout=timeout) as response:
        return json.load(response)


def registry_entry(selector: str, timeout: float) -> dict:
    url = os.environ["MODEL_GATEWAY_URL"].rstrip("/") + "/registry"
    request = urllib.request.Request(
        url, headers={"Authorization": "Bearer " + os.environ["MODEL_GATEWAY_API_KEY"],
                      "Accept": "application/json"}, method="GET")
    with _opener().open(request, timeout=timeout) as response:
        return json.load(response)["models"][selector]


def between(text: str, begin: str, end: str, what: str) -> str:
    """The exact bytes the pack placed between two marker lines, with no re-encoding."""
    open_marker, close_marker = begin + "\n", "\n" + end
    assert text.count(open_marker) == 1, f"{what}: the opening marker is not unique"
    assert text.count(close_marker) == 1, f"{what}: the closing marker is not unique"
    start = text.index(open_marker) + len(open_marker)
    stop = text.index(close_marker)
    assert stop > start, f"{what}: markers are out of order"
    return text[start:stop]


def parse_task_file(text: str) -> tuple[dict, str, str]:
    match = HEADER_RE.search(text)
    assert match, "the task file carries no vb103-judge-cell header"
    header = json.loads(match.group("json"))
    system = between(text, SYS_BEGIN, SYS_END, "system prompt")
    user = between(text, USER_BEGIN, USER_END, "user prompt")
    return header, system, user


def provider_config(entry: dict) -> dict:
    props = entry.get("provider_properties") or {}
    assert not props.get("fallback_models"), "selector must not carry fallback models"
    if (entry.get("provider_name") or "").lower() == "anthropic":
        config = {k: v for k, v in props.items() if v is not None and k in ANTHROPIC_ALLOWED}
        config["fallback_models"] = []
        return config
    return {k: v for k, v in props.items() if v is not None and k in OPENAI_ALLOWED}


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--problem-path", required=True, type=Path)
    ap.add_argument("--model", required=True)
    ap.add_argument("--task-id", required=True)
    ap.add_argument("--config", default="")
    ap.add_argument("--max-tokens", default="32000")
    ap.add_argument("--reasoning-effort", default="")
    ap.add_argument("--compute-effort", default="")
    ap.add_argument("--benchmark", default="veribench103-judge")
    ap.add_argument("--timeout", type=float, default=float(os.environ.get("VB103_CALL_TIMEOUT_S", "1800")))
    args = ap.parse_args()

    LOGS.mkdir(parents=True, exist_ok=True)
    receipt: dict = {"condition": "expt103-judge-transport-v1", "task_id": args.task_id,
                     "selector": args.model, "judge_config": args.config, "benchmark": args.benchmark,
                     "started": stamp(), "requests_sent": 0, "status": "RUNNING"}

    def save() -> None:
        receipt["updated"] = stamp()
        tmp = LOGS / "receipt.json.tmp"
        tmp.write_text(json.dumps(receipt, indent=2) + "\n")
        tmp.replace(LOGS / "receipt.json")

    save()
    text = args.problem_path.read_text(encoding="utf-8")
    try:
        header, system, user = parse_task_file(text)
    except (AssertionError, ValueError) as exc:
        receipt.update(status="unmeasured_infra", error_kind="TaskFileUnreadable", error=str(exc)[:300])
        save()
        return 3

    receipt.update(cell=header.get("cell"), system_sha256=sha(system.encode()),
                   user_sha256=sha(user.encode()),
                   prompt_sha256=sha((system + "\n\n" + user).encode()),
                   expected=dict(system=header.get("system_sha256"), user=header.get("user_sha256"),
                                 prompt=header.get("prompt_sha256")),
                   output_path=header.get("output_path"))
    save()
    # A judge call whose prompt bytes are not the frozen ones is worthless and must never be spent.
    if (receipt["system_sha256"] != header.get("system_sha256")
            or receipt["user_sha256"] != header.get("user_sha256")
            or receipt["prompt_sha256"] != header.get("prompt_sha256")):
        receipt.update(status="unmeasured_infra", error_kind="PromptHashMismatch")
        save()
        return 3
    output_path = header.get("output_path") or ""
    if not re.fullmatch(r"/home/user/lean_project/Veribench/[A-Za-z0-9_]+\.lean", output_path):
        receipt.update(status="unmeasured_infra", error_kind="UndeclaredOutputPath")
        save()
        return 3

    entry = registry_entry(args.model, 60.0)
    config: dict = {"max_tokens": int(args.max_tokens), "provider_config": provider_config(entry)}
    if args.reasoning_effort:
        config["reasoning_effort"] = args.reasoning_effort
    if args.compute_effort:
        config["compute_effort"] = args.compute_effort
    receipt["provider_endpoint"] = entry.get("provider_endpoint")
    receipt["config"] = {k: v for k, v in config.items() if k != "provider_config"}
    receipt["wire_provider_config"] = config["provider_config"]
    save()

    query = {"model": args.model, "config": config,
             "inputs": [{"kind": "system", "text": system}, {"kind": "text", "text": user}],
             "tools": [],
             "run_id": os.environ.get("VALKYRIE_RUN_ID", "vb103-judge"),
             "question_id": header.get("cell") or args.task_id,
             "query_id": f"vb103-{args.benchmark}-{args.task_id}",
             "identity": {"benchmark_name": args.benchmark, "agent_name": "vb103_judge"}}

    response, begin = None, time.monotonic()
    for attempt in (1, 2):
        receipt.update(requests_sent=attempt, attempt=attempt)
        save()
        try:
            response = gateway_request("/query", query, args.timeout)
            break
        except urllib.error.HTTPError as exc:
            receipt.update(status="unmeasured_infra", error_kind="HTTPError", http_status=exc.code)
            save()
            if exc.code in (429, 500, 502, 503, 504) and attempt == 1:
                time.sleep(60)
                continue
            return 3
        except (TimeoutError, socket.timeout) as exc:
            receipt.update(status="unmeasured_infra", error_kind=type(exc).__name__,
                           note="no response arrived; not replayed because the call may have been served")
            save()
            return 3
        except Exception as exc:  # noqa: BLE001 - every failure is recorded, never swallowed
            receipt.update(status="unmeasured_infra", error_kind=type(exc).__name__, error=str(exc)[:300])
            save()
            return 3

    receipt["wall_seconds"] = round(time.monotonic() - begin, 3)
    meta = response.get("metadata") or {}
    finish = response.get("finish_reason") or {}
    receipt.update(response_sha256=sha(json.dumps(response, sort_keys=True).encode()),
                   usage={k: meta.get(k) for k in ("in_tokens", "out_tokens", "reasoning_tokens",
                                                   "cache_read_tokens", "cache_write_tokens")},
                   cost_usd=(meta.get("cost") or {}).get("total"),
                   finish_reason=finish, fallback=meta.get("fallback"))
    if response.get("error"):
        receipt.update(status="model_error", error_type=(response["error"] or {}).get("exception_type"))
        save()
        return 0
    if meta.get("fallback"):
        receipt.update(status="unmeasured_infra", error_kind="UnexpectedFallback")
        save()
        return 3

    completion = response.get("output_text") or ""
    receipt.update(output_text_sha256=sha(completion.encode()), output_text_bytes=len(completion.encode()))
    (LOGS / "response.txt").write_text(completion)
    target = Path(output_path)
    target.parent.mkdir(parents=True, exist_ok=True)
    # The completion is the judge's verdict JSON; it is written verbatim (the host parses it with
    # experiment 100's frozen parser). A trailing newline keeps the collected file non-empty-safe.
    target.write_text(completion if completion.endswith("\n") else completion + "\n", encoding="utf-8")
    receipt["written_file"] = {"path": output_path, "bytes": target.stat().st_size,
                              "sha256": sha(target.read_bytes())}
    clean = str(finish.get("reason") or finish or "").lower() in CLEAN_FINISH
    if not completion.strip():
        receipt.update(status="incomplete", reason="the completion was empty")
    elif not clean:
        receipt.update(status="incomplete", reason=f"non-clean finish reason {finish!r}")
    else:
        receipt["status"] = "measured"
    receipt["ended"] = stamp()
    save()
    print(json.dumps({k: receipt.get(k) for k in ("task_id", "selector", "judge_config", "status",
                                                  "output_text_bytes", "cost_usd")}))
    return 0


if __name__ == "__main__":
    sys.exit(main())
